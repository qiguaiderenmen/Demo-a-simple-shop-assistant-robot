#!/usr/bin/env python
# -*- coding:UTF-8 -*-

"""
    navigation.py - Say back what is heard by the pocketsphinx recognizer.
"""

import roslib; roslib.load_manifest('speech')
import rospy
from std_msgs.msg import String
from std_msgs.msg import Int8
import os

from sound_play.libsoundplay import SoundClient

class gpsr:

	def __init__(self):
		rospy.on_shutdown(self.cleanup)
		self.voice = rospy.get_param("~voice", "voice_cmu_us_clb_arctic_clunits")
		self.wavepath = rospy.get_param("~wavepath", "")
		self.question_start_signal = rospy.get_param("~question_start_signal", "")
		self.state="true"
		self.soundhandle=SoundClient()
		rospy.sleep(1)
		self.soundhandle.stopAll()
		rospy.sleep(1)
                self.back2start_pub = rospy.Publisher('/back2Start', String, queue_size=15)
		self.loc_pub = rospy.Publisher('/speechGiveLocation', String, queue_size=15)
		self.find_target_thing_pub = rospy.Publisher('/imgFindTargetThing', String, queue_size=15)
		self.find_person_pub = rospy.Publisher('/nav2image', String, queue_size=15)
		rospy.Subscriber('/arriveLocation',String,self.reachdst_callback)
		rospy.Subscriber('/emergency2speech',String,self.emergency_callback)
		rospy.Subscriber('/found_person',String,self.askhelp)
		self.difmsg='null'
		self.if_backToStart=0
		self.soundhandle.say("ok I am ready",self.voice)
		rospy.sleep(3)
		self.step=-1
		self.confirm_thing=0

		self.if_locpub=0
		self.if_locpub_right=0
		self.if_listen_action=0
                self.if_action_right=0
		self.if_listen_thing=0
                self.if_thing_right=0
                self.if_confirm=0

		self.if_now_answer=0

		self.is_it_edible=0
		self.is_it_solid=0
		self.is_it_snack=0
		self.is_it_sweet=0
		self.mood=0

		self.candidate_loc=""
		self.candidate_target=""
		self.candidate_action=""
		self.target_place = ""
		self.target_action = ""
		self.target_target = ""

		self.is_listen_target=0
		self.is_listen_thing=0
		self.is_listen_person=0
		self.find_target_num=0
		self.find_thing_num=0
		self.find_person_num=0
		self.target_in_sentence=[]
		self.thing_in_sentence=[]
		self.person_in_sentence=[]
		self.confirm_thing=0
		self.confirm_person=0
		self.is_answer_question=0

		self.location=['food-shelf','drink-shelf','refidgerator','manager']
		self.thing1111=['ice-cream','milk-tea','cola']
		self.thing1110=['cup star','curry','chips']
		self.thing1101=['maize','onion','radish']
		self.thing1100=['apple','bread','orange']
		self.thing10=['water','cola','beer','green tea']
		self.thing011=['peanut','hair gel','shampoo']
		self.thing010=['emollient cream']
		self.thing001=['bowl','plate','soup bowl']
		self.thing000=['chopsticks','fork','spoon']

		self.alltarget=['milk','chewing-gum','jelly','cup-star','curry','chips','maize','onion','radish'
				,'apple','bread','orange','water','cola','beer','green-tea','peanut','hair-gel'
				,'shampoo','emollient-cream','bowl','plate','soup-bowl','chopsticks','spoon','fork'
				,'tom','jane','lucy','james','tony','ben','miller','michael','andrew','jordon','answer-some-questions']
		self.allthing=['coke','chocolate','chips','biscuits','coffee','milk','raincoat','umbrella','bread'
				,'afternoon-tea','ice-cream','milk-tea','rice','cola']

		self.key_sentence=""

		self.alltarget_num=0
		self.allthing_num=0
		self.allperson_num=0
		self.location_num=0
		self.thing1111_num=0
		self.thing1110_num=0

		self.soundhandle.say("do you want me recommand something for you",self.voice)
		rospy.sleep(5)
		os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")
		rospy.Subscriber('recognizer_output',String,self.listen_callback)
	def emergency_callback(self,msg):
		msg.data=msg.data.lower()
		if msg.data=="true":
			self.state="true"
		else :
			self.state="false"
	def listen_callback(self,msg):
		msg.data=msg.data.lower()
		print msg.data
#-------------------------------first step----------------------------------------------------------------
		if msg.data.find('james')>-1 and self.step==-1:
			self.key_sentence=msg.data
			if (msg.data.find('i-do-not-need') )> -1:	

				os.system('gedit ~/catkin_ws/things.txt')

				msg.data=""
				self.if_locpub=1
				self.if_locpub_right=1
				self.step=0
				self.soundhandle.say("one",self.voice)
				rospy.sleep(1)
			if (msg.data.find('yes-thank-you')) > -1:
				msg.data=""	
				self.step=1
				self.if_locpub=1
				self.if_locpub_right=0
#-------------------------------------------------------------------------------------------------
		if msg.data.find('james')>-1 and self.if_locpub==1 and self.if_locpub_right==1 and self.is_listen_thing==0 and self.step==0:
			self.soundhandle.say("two",self.voice)
			rospy.sleep(1)
			self.key_sentence=msg.data
			msg.data=""
			self.if_locpub_right=1	
			os.system("/home/kamerider/catkin_ws/src/speech/kill_pocketsphinx.sh")

			for thing in self.allthing:
				if self.key_sentence.find(thing)>-1:
					self.thing_in_sentence.append(thing)
			
			if len(self.thing_in_sentence)>0:
				self.soundhandle.say("is things you want in the list",self.voice)
				rospy.sleep(3)
				self.is_listen_target=1
				for x in self.thing_in_sentence:
					self.soundhandle.say(x,self.voice)
					print x
					rospy.sleep(2)
				os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")
			self.is_listen_thing=1
				


#------------------------------------------------在list范围内就可以开问具体thing,不是thing问是不是人------------------------------------------------------------
		if msg.data.find('james')>-1 and self.if_locpub==1 and self.if_locpub_right==1  and self.confirm_thing==0 and self.is_listen_thing==1 and self.step==0:
			if msg.data.find('yes-thank-you') > -1:					
				#如果语句中有物品出现
				msg.data=""
				os.system("/home/kamerider/catkin_ws/src/speech/kill_pocketsphinx.sh")
				self.candidate_target=self.thing_in_sentence[self.find_thing_num]
				self.candidate_action="take"
				self.soundhandle.say("so should I go there",self.voice)
				rospy.sleep(3)
				self.soundhandle.say("and take a",self.voice)
			        rospy.sleep(2)
				self.soundhandle.say(self.thing_in_sentence[self.find_thing_num],self.voice)
				rospy.sleep(2)
				self.soundhandle.playWave(self.question_start_signal+"/question_start_signal.wav")
				rospy.sleep(1.3)
				os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")
				self.confirm_thing=1
				self.find_thing_num=self.find_thing_num+1
				



#-------------------------------------------------------看看物体识别的对不对----------------------------------------------------------------
		if msg.data.find('james')>-1 and self.if_locpub_right==1 and self.confirm_thing==1 and self.is_listen_thing==1 and self.step==0:
			#---------------------------------------物体也正确的话发消息--------------------------------------			
			if msg.data.find('yes-thank-you') > -1:
				msg.data=""
				self.target_target = self.candidate_target
				os.system("/home/kamerider/catkin_ws/src/speech/kill_pocketsphinx.sh")
				self.soundhandle.say("ok I will go there and take",self.voice)
                                rospy.sleep(5)
				self.soundhandle.say(self.target_target,self.voice)
				rospy.sleep(2)
				#这里给navigation发topic
				if self.target_target == "milk":
					self.loc_pub.publish("drink-shelf")
				os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")
			if msg.data.find('no-good-answer') > -1:
				msg.data=""
				os.system("/home/kamerider/catkin_ws/src/speech/kill_pocketsphinx.sh")
				if len(self.thing_in_sentence)>self.find_thing_num:
					self.candidate_target=self.thing_in_sentence[self.find_thing_num]
					self.candidate_action="take"
					self.soundhandle.say("so should I go there",self.voice)
					rospy.sleep(3)
					self.soundhandle.say("and take a",self.voice)
				        rospy.sleep(2)
					self.soundhandle.say(self.candidate_target,self.voice)
					rospy.sleep(2)
					self.soundhandle.playWave(self.question_start_signal+"/question_start_signal.wav")
					rospy.sleep(1.3)
					os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")
					self.confirm_thing=1
					self.find_thing_num=self.find_thing_num+1
				else:
					self.soundhandle.say("ok let me guess what you want me to do",self.voice)
					rospy.sleep(5)
					self.step=1
					self.confirm_thing=0

					self.if_locpub=1
					self.if_locpub_right=0
					self.if_listen_action=0
					self.if_action_right=0
					self.if_listen_thing=0
					self.if_thing_right=0
					self.if_confirm=0

					self.if_now_answer=0

					self.is_it_edible=0
					self.is_it_solid=0
					self.is_it_snack=0
					self.is_it_sweet=0

					self.candidate_target=""
					self.candidate_action=""
					self.target_action = ""
					self.target_target = ""

					self.find_thing_num=0
					self.thing_in_sentence=[]
					os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")





#-------------------------------second step--------------------------------------------------------------------------------------------
#------------------------------这个if用来确认完地点正确后询问动作------------------------------------------
		if self.if_locpub==1 and self.if_locpub_right==0 and self.step==1:
			msg.data=""	
			os.system("/home/kamerider/catkin_ws/src/speech/kill_pocketsphinx.sh")
			self.soundhandle.say("should I go there to take something",self.voice)
                        rospy.sleep(5.5)
			self.soundhandle.playWave(self.question_start_signal+"/question_start_signal.wav")
			rospy.sleep(1.3)
			os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")
                        self.if_locpub_right=1
			self.if_listen_action=1
#------------------------------这个if用来确认完动作后询问对象----------------------------------------------
                if msg.data.find('james')>-1 and self.if_locpub_right==1 and self.if_listen_action==1 and self.if_action_right==0 and self.step==1:
			if msg.data.find('yes-thank-you') > -1:	
				msg.data=""              
				self.target_action = "take"	
				os.system("/home/kamerider/catkin_ws/src/speech/kill_pocketsphinx.sh")
				self.soundhandle.say("ok I will go there to take something",self.voice)
                                rospy.sleep(4.5)
				self.soundhandle.say("are you hungry sir",self.voice)
                                rospy.sleep(2.5)
				self.soundhandle.playWave(self.question_start_signal+"/question_start_signal.wav")
				rospy.sleep(1.3)
				os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")
                                self.if_action_right=1
				self.if_listen_thing=1
#-----------------------------这个if用来确认对象并确认三个target----------------------------------
                if self.if_action_right==1 and self.if_listen_thing==1 and self.if_thing_right==0 and self.step==1:
			if self.is_it_edible==0:
				if msg.data.find('i-feel-extremely-hungry') > -1:	
					self.is_it_edible=1
					msg.data=""
					os.system("/home/kamerider/catkin_ws/src/speech/kill_pocketsphinx.sh")
					self.soundhandle.say("then are you thirsty sir",self.voice)
		                        rospy.sleep(3.5)
					self.soundhandle.playWave(self.question_start_signal+"/question_start_signal.wav")
					rospy.sleep(1.3)
					os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")
				if msg.data.find('no hungry') > -1:	
					self.is_it_edible==-1
					msg.data=""
			#进入1分支
			if self.is_it_edible==1:
				if self.is_it_solid==0:
					if msg.data.find('not-that-thirsty') > -1:	
						#11
						self.is_it_solid=1
						msg.data=""
						os.system("/home/kamerider/catkin_ws/src/speech/kill_pocketsphinx.sh")
						self.soundhandle.say("and how do you do sir",self.voice)
				                rospy.sleep(3.5)
						self.soundhandle.playWave(self.question_start_signal+"/question_start_signal.wav")
						rospy.sleep(1.3)
						os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")
						
					
							
					#进入10分支
					if msg.data.find('no-good-answer') > -1:	
						self.is_it_solid=-1
						msg.data=""
						os.system("/home/kamerider/catkin_ws/src/speech/kill_pocketsphinx.sh")
						self.soundhandle.say("is it a snack",self.voice)
				                rospy.sleep(3.5)
						self.soundhandle.playWave(self.question_start_signal+"/question_start_signal.wav")
						rospy.sleep(1.3)
						os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")

				#进入11分支
				if self.is_it_solid==1:
					if self.mood==0:
						if msg.data.find('i-am-happy-today') > -1:	
							self.mood=1
							msg.data=""
							os.system("/home/kamerider/catkin_ws/src/speech/kill_pocketsphinx.sh")
							self.soundhandle.say("so i prefer this for you",self.voice)
							rospy.sleep(5)
							self.soundhandle.say(self.thing1111[self.thing1111_num%3],self.voice)
							self.thing1111_num=self.thing1111_num+1
							rospy.sleep(3.5)
							self.soundhandle.playWave(self.question_start_signal+"/question_start_signal.wav")
							rospy.sleep(1.3)
							os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")
					if self.mood==1:#111
						if msg.data.find('yes-thank-you') > -1:
							self.soundhandle.say("ok i will go there",self.voice)
							print self.thing1111[self.thing1111_num-1]
							if self.thing1111[self.thing1111_num-1]=="ice-cream":
								self.soundhandle.say("ok i will go to fridge to take it for you",self.voice)
								rospy.sleep(5)
								self.loc_pub.publish("refridgerator")#public东西
						if msg.data.find('no-i-do-not-need') > -1:
							msg.data=""
							os.system("/home/kamerider/catkin_ws/src/speech/kill_pocketsphinx.sh")
							self.soundhandle.say("then i recommand this",self.voice)
							rospy.sleep(2.5)
							self.soundhandle.say(self.thing1111[self.thing1111_num%3],self.voice)
							self.thing1111_num=self.thing1111_num+1
							rospy.sleep(3.5)
							self.soundhandle.playWave(self.question_start_signal+"/question_start_signal.wav")
							rospy.sleep(1.3)
							os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")
						
				#进入10分支
				if self.is_it_solid==-1:
					if msg.data.find('ok-very-good') > -1:	
						msg.data=""
						self.target_target = self.thing10[(self.thing10_num-1)%4]	
						os.system("/home/kamerider/catkin_ws/src/speech/kill_pocketsphinx.sh")
						self.soundhandle.say("so should I go to",self.voice)
						rospy.sleep(3.5)
						self.soundhandle.say(self.target_place,self.voice)
						rospy.sleep(2)
						self.soundhandle.say(self.target_action,self.voice)
						rospy.sleep(1)
						self.soundhandle.say(self.target_target,self.voice)
						rospy.sleep(2)
						self.soundhandle.playWave(self.question_start_signal+"/question_start_signal.wav")
						rospy.sleep(1.3)
						#os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")
						self.if_thing_right=1
						self.if_confirm=1
					if msg.data.find('no-good-answer') > -1:	
						msg.data=""
						os.system("/home/kamerider/catkin_ws/src/speech/kill_pocketsphinx.sh")
						self.soundhandle.say("is it",self.voice)
						rospy.sleep(1)
						self.soundhandle.say(self.thing10[self.thing10_num%4],self.voice)
						self.thing10_num=self.thing10_num+1
						rospy.sleep(3.5)
						self.soundhandle.playWave(self.question_start_signal+"/question_start_signal.wav")
						rospy.sleep(1.3)
						os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")
					
		

#--------------------------------------------------------------------------------------------------
		else :
			return
	def askhelp(self,msg):
		msg.data=msg.data.lower()
		if msg.data=="found_person":
			os.system("~/catkin_ws/src/speech/kill_pocketsphinx.sh")
			self.soundhandle.say(" new operator ",self.voice)
			rospy.sleep(1.5)
			self.soundhandle.say(" i have reached the person ",self.voice)
			rospy.sleep(3)
			self.soundhandle.say('ok I will go back now', self.voice)
			rospy.sleep(3)
			self.soundhandle.say('byebye', self.voice)
			rospy.sleep(2)
			
			self.loc_pub.publish("start")
			self.if_if_now_answer=0
			self.if_backToStart=1
			os.system("~/catkin_ws/src/speech/run_pocketsphinx.sh")
	def reachdst_callback(self,msg):
		msg.data=msg.data.lower()
		#到达operator指定的目的地
		if msg.data=="arrive_target_place" and self.if_backToStart==0:
			self.soundhandle.say("now I arrived",self.voice)
			rospy.sleep(3.5)
                        self.soundhandle.say("i will pick what you choose for you",self.voice)
			rospy.sleep(6)
			self.loc_pub.publish("start")
			self.if_backToStart=1
		#回到初始地
		if msg.data=="arrive_target_place" and self.if_backToStart==1:
			#初始化所有的flag开始新的一轮
			self.if_locpub=0
			self.if_locpub_right=0
			self.if_listen_action=0
		        self.if_action_right=0
			self.if_listen_thing=0
		        self.if_thing_right=0
		        self.if_confirm=0
			self.step=-1
			self.if_now_answer=0

			self.is_it_edible=0
			self.is_it_solid=0
			self.is_it_snack=0
			self.is_it_sweet=0

			self.candidate_loc=""
			self.target_place = ""
			self.target_action = ""
			self.target_target = ""


			self.location_num=0
			self.thing1111_num=0
			elf.thing1110_num=0
			self.soundhandle.say("now I am ready for next turn",self.voice)
			rospy.sleep(4)
			os.system("/home/kamerider/catkin_ws/src/speech/run_pocketsphinx.sh")
			
			

	def cleanup(self):
		rospy.loginfo("shuting down navsp node ....")


if __name__=="__main__":
	rospy.init_node('gpsr')
	try:
		gpsr()
		rospy.spin()
	except:
		pass
