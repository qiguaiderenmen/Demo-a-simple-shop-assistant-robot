echo "riddle.launch start"
gnome-terminal -x bash -c "killall pocketsphinx_continuous"


sleep 1
