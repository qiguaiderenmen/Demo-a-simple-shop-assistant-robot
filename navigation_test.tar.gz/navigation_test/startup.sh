#!/bin/bash
cd ~/turtlebot
source devel/setup.bash
roslaunch turtlebot_follower follower1.launch
