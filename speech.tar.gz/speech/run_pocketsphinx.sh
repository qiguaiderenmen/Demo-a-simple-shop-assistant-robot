echo "gpsr.launch start"
gnome-terminal -x bash -c "pocketsphinx_continuous -inmic yes -dict /home/kamerider/catkin_ws/src/speech/voice_library/gpsr/3608.dic -lm /home/kamerider/catkin_ws/src/speech/voice_library/gpsr/3608.lm;"


sleep 1
